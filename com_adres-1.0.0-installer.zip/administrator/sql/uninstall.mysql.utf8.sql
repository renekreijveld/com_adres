DROP TABLE IF EXISTS `#__com_adres`;

DELETE FROM `#__content_types` WHERE (type_alias LIKE 'com_adres.%');