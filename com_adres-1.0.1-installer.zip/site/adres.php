<?php
/**
 * @version    CVS: 1.0.0
 * @package    Com_Adres
 * @author     Rene Kreijveld <email@renekreijveld.nl>
 * @copyright  Copyright Rene Kreijveld (C) 2016. All rights reserved.
 * @license    GNU General Public License version 2 or later; see LICENSE.txt
 */

defined('_JEXEC') or die;

// Include dependancies
jimport('joomla.application.component.controller');

JLoader::registerPrefix('Adres', JPATH_COMPONENT);

// Execute the task.
$controller = JControllerLegacy::getInstance('Adres');
$controller->execute(JFactory::getApplication()->input->get('task'));
$controller->redirect();